#-*- coding:utf-8 -*-

from controllers import create_Scatter_plot as __create_Scatter_plot__
from controllers import create_Trend as __create_Trend__
from controllers import create_Cpk as __create_Cpk__
from controllers import create_Spc as __create_Spc__
from controllers import compression as __compression__
# 처리하는, 연결하는 영역 가져오기
