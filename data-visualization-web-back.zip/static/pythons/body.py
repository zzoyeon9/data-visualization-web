#-*- coding:utf-8 -*-

"""
DOM 사용
"""
from browser import document
from browser.widgets.dialog import InfoDialog
