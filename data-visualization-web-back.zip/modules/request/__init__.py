#-*- coding:utf-8 -*-

"""Request
"""

__all__ = [
    "Request",
]

from fastapi import Request as Request
