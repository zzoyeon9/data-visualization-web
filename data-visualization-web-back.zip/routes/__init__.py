#-*- coding:utf-8 -*-

"""Routes
"""

# Routes
from routes import event as __event__
from routes import index as __index__
from routes import scatter_plot as __scatter_plot__
from routes import trend_chart as __trend_chart__
from routes import cpk_chart as __cpk_chart__
from routes import spc_chart as __spc_chart__
from routes import download_charts as __download_charts__
